//
//  UsePinAttendence.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 22/08/21.
//

#import "UsePinAttendence.h"

@interface UsePinAttendence ()
@property (weak, nonatomic) IBOutlet UITextField *textFiledPw;
@property (weak, nonatomic) IBOutlet UIView *alertView;

@end

@implementation UsePinAttendence


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    _alertView.hidden=YES;
}

-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
      [self.view endEditing:YES];// this will do the trick
}

- (IBAction)back:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}


- (IBAction)submit:(id)sender {
    
    _alertView.hidden=NO;

    
}

- (IBAction)back2:(id)sender {
    
    _alertView.hidden=YES;
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"AttendenceScreen"];
    [self presentViewController:vc animated:NO completion:nil];
}

@end
