//
//  AttendenceScreen.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 21/08/21.
//

#import "AttendenceScreen.h"
#import "MBProgressHUD.h"

@interface AttendenceScreen ()

@end

@implementation AttendenceScreen

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
    
}


- (IBAction)backBtn:(id)sender {
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"HomeScreen"];
    [self presentViewController:vc animated:NO completion:nil];
    
}


- (IBAction)scanBtn:(id)sender {
    
    UIImagePickerController *picker = [[UIImagePickerController alloc] init];
       picker.delegate = self;
       picker.allowsEditing = YES;
       picker.sourceType = UIImagePickerControllerSourceTypeCamera;

       [self presentViewController:picker animated:YES completion:NULL];
}



- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {

    UIImage *chosenImage = info[UIImagePickerControllerEditedImage];
   // self.imageView.image = chosenImage;

    [picker dismissViewControllerAnimated:YES completion:NULL];
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(timerCalled) userInfo:nil repeats:NO];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}



-(void)timerCalled{
    
    [MBProgressHUD hideHUDForView:self.view animated:NO];
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"CarDetail"];
    [self presentViewController:vc animated:NO completion:nil];
    
}
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker {

    [picker dismissViewControllerAnimated:YES completion:NULL];

}



- (IBAction)usePin:(id)sender {
    

    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"UsePinAttendence"];
    [self presentViewController:vc animated:NO completion:nil];
    
    
}

- (IBAction)usemanually:(id)sender {
    
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(timerCalled2) userInfo:nil repeats:NO];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    
 
    
}



-(void)timerCalled2{
    
    [MBProgressHUD hideHUDForView:self.view animated:NO];

    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"ManuallyAddVin"];
    [self presentViewController:vc animated:NO completion:nil];
    
}




- (IBAction)back:(id)sender {
}

@end
