//
//  SceneDelegate.h
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/05/21.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

