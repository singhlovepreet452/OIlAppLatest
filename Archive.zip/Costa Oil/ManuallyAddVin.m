//
//  ManuallyAddVin.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/09/21.
//

#import "ManuallyAddVin.h"
#import "MBProgressHUD.h"

@interface ManuallyAddVin ()
@property (weak, nonatomic) IBOutlet UITextField *textFiledMuny;

@end

@implementation ManuallyAddVin


- (void)viewDidLoad {
    
    
    [super viewDidLoad];
    
    _textFiledMuny.delegate=self;
    
    
    _textFiledMuny.layer.borderColor = [UIColor darkGrayColor].CGColor;
    _textFiledMuny.layer.borderWidth = 1;
    _textFiledMuny.layer.cornerRadius = 10;
    _textFiledMuny.layer.masksToBounds = true;
    
    
    if ([_textFiledMuny respondsToSelector:@selector(setAttributedPlaceholder:)]) {
      UIColor *color = [UIColor grayColor];
        _textFiledMuny.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"VIN Number" attributes:@{NSForegroundColorAttributeName: color}];
    } else {
      NSLog(@"Cannot set placeholder text's color, because deployment target is earlier than iOS 6.0");
      // TODO: Add fall-back code to set placeholder color.
    }
    
    
}


-(BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    [self.view endEditing:YES];

    return YES;
    
}


-(void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event{
      [self.view endEditing:YES];// this will do the trick
}


- (IBAction)back:(id)sender {
    
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

- (IBAction)submit:(id)sender {
    
    
  
    
    NSTimer *timer = [NSTimer scheduledTimerWithTimeInterval:3 target:self selector:@selector(timerCalled) userInfo:nil repeats:NO];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
}



-(void)timerCalled{
    
    [MBProgressHUD hideHUDForView:self.view animated:NO];
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"CarDetail"];
    [self presentViewController:vc animated:NO completion:nil];
    
}

@end
