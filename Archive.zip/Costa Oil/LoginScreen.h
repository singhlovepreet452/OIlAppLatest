//
//  LoginScreen.h
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/05/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface LoginScreen : UIViewController

@end

NS_ASSUME_NONNULL_END
