//
//  AvailableOilList.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 17/05/21.

#import "AvailableOilList.h"

@interface AvailableOilList ()

@property (weak, nonatomic) IBOutlet UIScrollView *ScrollView;

@end

@implementation AvailableOilList


- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [_ScrollView setContentSize:CGSizeMake(320, 900)];
    [_ScrollView setScrollEnabled:TRUE];
    [_ScrollView setShowsVerticalScrollIndicator:NO];
    [_ScrollView setShowsHorizontalScrollIndicator:YES];
    
}


- (IBAction)back:(id)sender {
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"HomeScreen"];
    [self presentViewController:vc animated:NO completion:nil];
    
}


@end
