//
//  AttendenceScreen.h
//  Costa Oil
//
//  Created by Lovepreet Singh on 21/08/21.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface AttendenceScreen : UIViewController<UINavigationControllerDelegate,UIImagePickerControllerDelegate>

@end

NS_ASSUME_NONNULL_END
