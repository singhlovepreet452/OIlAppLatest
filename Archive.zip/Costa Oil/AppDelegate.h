//
//  AppDelegate.h
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/05/21.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

