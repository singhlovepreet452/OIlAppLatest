//
//  CarDetail.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 16/09/21.
//

#import "CarDetail.h"

@interface CarDetail ()

@end

@implementation CarDetail

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
    
    
}


- (IBAction)back:(id)sender {
    
    [self dismissViewControllerAnimated:YES completion:nil];
    
}

@end
