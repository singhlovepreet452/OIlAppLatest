//
//  HomeScreen.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 17/05/21.
//

#import "HomeScreen.h"
#import "PGDrawerTransition.h"
#import "SideView.h"
#import "MBProgressHUD.h"

@interface HomeScreen ()

@property (nonatomic, strong) PGDrawerTransition *drawerTransition;
@property (nonatomic, strong) SideView *drawerViewController;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIView *backViewList;
@property (weak, nonatomic) IBOutlet UITextField *searchTxt;

@end

@implementation HomeScreen

{
    
    UITableViewCell *cell;
    NSMutableArray *carNoArray;
    NSMutableArray *descriptionArray;
    NSString *SearchValue;
    
}

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        self->SearchValue = @"";

        self->_backViewList.layer.cornerRadius = 27;
        self->_backViewList.clipsToBounds = YES;
    
    
        if ([self->_searchTxt respondsToSelector:@selector(setAttributedPlaceholder:)]){
        
      UIColor *color = [UIColor grayColor];
        
            self->_searchTxt.attributedPlaceholder = [[NSAttributedString alloc] initWithString:@"search by car no" attributes:@{NSForegroundColorAttributeName: color}];
        
    } else {
        
      NSLog(@"Cannot set placeholder text's color, because deployment target is earlier than iOS 6.0");
      // TODO: Add fall-back code to set placeholder color.
        
    }
    
        [self->_scrollView setContentSize:CGSizeMake(320, 900)];
        [self->_scrollView setScrollEnabled:TRUE];
        [self->_scrollView setShowsVerticalScrollIndicator:NO];
        [self->_scrollView setShowsHorizontalScrollIndicator:YES];
        
        self->_searchTxt.delegate=self;
    
    
    self->_tableView.delegate        =  self;
    self->_tableView.dataSource      =  self;
    self->_tableView.backgroundColor = [UIColor clearColor];
    self->_tableView.separatorColor  = [UIColor clearColor];
    [self->_tableView setShowsHorizontalScrollIndicator:NO];
    [self->_tableView setShowsVerticalScrollIndicator:NO];
    
    
    UIStoryboard *pushStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    self.drawerViewController = [pushStoryBoard instantiateViewControllerWithIdentifier:@"SideView"];
    self.drawerTransition = [[PGDrawerTransition alloc] initWithTargetViewController:self
                                                                drawerViewController:self
                             .drawerViewController];
        
        [self->_searchTxt addTarget:self
                      action:@selector(textFieldDidChange:)
            forControlEvents:UIControlEventEditingChanged];
    
    [self ListApi];
    });
}


- (void)textFieldDidChange:(UITextField *)textField {
    
    dispatch_async(dispatch_get_main_queue(), ^{

        self->SearchValue = self->_searchTxt.text;
    
       [self searchAPI];
        
    });
}



-(void)searchAPI {
    
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];

    
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    NSLog(@"%@",queue);
    
    NSString *BaseUrl = @"https://easycoding.com.co/CoastaOil/api/search.php";
    
    NSString *ProperUrl = [NSString stringWithFormat:@"%@",BaseUrl];
    
    NSMutableURLRequest *urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:ProperUrl]];
    
    NSString *userUpdate = [NSString stringWithFormat:@"carno=%@",SearchValue];
    
    //create the Method "GET" or "POST"
    [urlRequest setHTTPMethod:@"POST"];
    
    //Convert the String to Data
    NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
    
    //Apply the data to the body
    [urlRequest setHTTPBody:data1];
    
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        
        if (httpResponse.statusCode == 200)
            
        {
            
            NSError *parseError = nil;
            
            NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
            
            NSLog(@"The response is - %@",responseDictionary);
            
            NSArray *values = [responseDictionary allValues];
            
            NSLog(@"%@",values);
            
            NSString * result = [NSString stringWithFormat:@"%@",[responseDictionary valueForKey:@"status"]];
            
            NSArray *dataArray=[[NSArray alloc]initWithArray:[responseDictionary valueForKey:@"data"]];
                               
            NSLog(@"%@",dataArray);
            
            if ([result isEqualToString:@"1"]) {
                
                self->carNoArray = [[NSMutableArray alloc]init];
                 self->descriptionArray= [[NSMutableArray alloc]init];

                
                dispatch_async(dispatch_get_main_queue(),^ {
                              
                    self->_tableView.hidden=NO;
                       });
        
                    
                        for (int i=0; i<dataArray.count; i++) {
                                     
                                     NSString *created_at = [[dataArray valueForKey:@"car_no"]objectAtIndex:i];
                                     [self->carNoArray addObject:created_at];

                                     NSString *hourly_wage = [[dataArray valueForKey:@"description"]objectAtIndex:i];
                                     [self->descriptionArray addObject:hourly_wage];
                                    
                       }

                    
                    
                 dispatch_async(dispatch_get_main_queue(),^ {
                     
                     self->_tableView.hidden=NO;
                                      
                     [self->_tableView reloadData];
                     [MBProgressHUD hideHUDForView:self.view animated:NO];


           });
                 

            
                
            }
            
            else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    self->_tableView.hidden=NO;
                    [MBProgressHUD hideHUDForView:self.view animated:NO];


                });
                
            }
            
        }
        
    }];
    
    [dataTask resume];
    
}


-(void)ListApi{
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];


    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    
    NSLog(@"%@",queue);
    
    NSString *BaseUrl = @"https://easycoding.com.co/CoastaOil/api/home.php";
    
    NSString *ProperUrl = [NSString stringWithFormat:@"%@",BaseUrl];
    
    NSMutableURLRequest *urlRequest = [[NSMutableURLRequest alloc] initWithURL:[NSURL URLWithString:ProperUrl]];
    
    
  
    NSString *userUpdate = [NSString stringWithFormat:@""];
    
    //create the Method "GET" or "POST"
    [urlRequest setHTTPMethod:@"GET"];
    
    //Convert the String to Data
    NSData *data1 = [userUpdate dataUsingEncoding:NSUTF8StringEncoding];
    
    //Apply the data to the body
    [urlRequest setHTTPBody:data1];
    
    NSURLSession *session = [NSURLSession sharedSession];
    
    NSURLSessionDataTask *dataTask = [session dataTaskWithRequest:urlRequest completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
        
        if (httpResponse.statusCode == 200)
            
        {
            
            NSError *parseError = nil;
            
            NSDictionary *responseDictionary = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
            
            NSLog(@"The response is - %@",responseDictionary);
            
            NSArray *values = [responseDictionary allValues];
            
            NSLog(@"%@",values);
            
            NSString * result = [NSString stringWithFormat:@"%@",[responseDictionary valueForKey:@"status"]];
            
            NSArray *dataArray=[[NSArray alloc]initWithArray:[responseDictionary valueForKey:@"data"]];
                               
            NSLog(@"%@",dataArray);
            
            
            
            if ([result isEqualToString:@"1"]) {
                
                self->carNoArray = [[NSMutableArray alloc]init];
                 self->descriptionArray= [[NSMutableArray alloc]init];

                
                dispatch_async(dispatch_get_main_queue(),^ {
                              
                    self->_tableView.hidden=NO;
                       });
        
                    
                        for (int i=0; i<dataArray.count; i++) {
                                     
                                     NSString *created_at = [[dataArray valueForKey:@"car_no"]objectAtIndex:i];
                                     [self->carNoArray addObject:created_at];

                                     NSString *hourly_wage = [[dataArray valueForKey:@"description"]objectAtIndex:i];
                                     [self->descriptionArray addObject:hourly_wage];
                                    
                       }

                    
                    
                 dispatch_async(dispatch_get_main_queue(),^ {
                     
                     self->_tableView.hidden=NO;
                                      
                     [self->_tableView reloadData];
                     [MBProgressHUD hideHUDForView:self.view animated:NO];


           });
                 

            
                
            }
            
            else{
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    self->_tableView.hidden=NO;
                    [MBProgressHUD hideHUDForView:self.view animated:NO];


                });
                
            }
            
        }
        
    }];
    
    [dataTask resume];
    
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section

{
    return carNoArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    cell = [_tableView dequeueReusableCellWithIdentifier:@"cell"];

    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
        cell.backgroundColor = [UIColor clearColor];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    
    
    for (UIView *view in cell.contentView.subviews){
            
        [view removeFromSuperview];
            
    }

    
    UIView *BackView = [[ UIView alloc]initWithFrame:CGRectMake(10, 20, 380, 100)];
    BackView.backgroundColor=[UIColor colorWithRed: 0.91 green: 0.97 blue: 0.91 alpha: 1.00];
    BackView.layer.cornerRadius = 11;
    BackView.clipsToBounds = YES;
    [cell.contentView addSubview:BackView];

    UILabel *DateLbl = [[UILabel alloc]initWithFrame:CGRectMake(110, 30, 300, 40)];
    DateLbl.textColor = [UIColor blackColor];
    DateLbl.text = [carNoArray objectAtIndex:indexPath.row];
    [DateLbl setFont:[UIFont boldSystemFontOfSize:20]];
    DateLbl.backgroundColor =[UIColor clearColor];
    [cell.contentView addSubview:DateLbl];
    
    UILabel *descripLbl = [[UILabel alloc]initWithFrame:CGRectMake(110, 60, 300, 40)];
    descripLbl.textColor = [UIColor grayColor];
    descripLbl.text = [descriptionArray objectAtIndex:indexPath.row];
    [descripLbl setFont:[UIFont boldSystemFontOfSize:15]];
    descripLbl.backgroundColor =[UIColor clearColor];
    [cell.contentView addSubview:descripLbl];
    
            
    UIImageView *dot =[[UIImageView alloc] initWithFrame:CGRectMake(25,53,60,50)];
    dot.image = [UIImage imageNamed:@"img_car-1"];
    [cell.contentView addSubview:dot];
            
    
    return cell;
    
    
}


-(void) tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    if([indexPath row] == ((NSIndexPath*)[[tableView indexPathsForVisibleRows] lastObject]).row){
      
    }
    
}



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 120;
}



- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
//
    
}




- (IBAction)Menu:(id)sender {
    
    [self.drawerTransition presentDrawerViewController];

    
}
- (IBAction)plus:(id)sender {
}

@end
