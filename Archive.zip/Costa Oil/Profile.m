//
//  Profile.m
//  Costa Oil
//
//  Created by Lovepreet Singh on 17/05/21.
//

#import "Profile.h"

@interface Profile ()

@end

@implementation Profile

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    
}

- (IBAction)back:(id)sender {
    
    NSString * storyboardName = @"Main";
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:storyboardName bundle: nil];
    UIViewController * vc = [storyboard instantiateViewControllerWithIdentifier:@"HomeScreen"];
    [self presentViewController:vc animated:NO completion:nil];
    
}

@end
